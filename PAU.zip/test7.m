#seventh example throws error
A = [1 2 1 1;2 1 -2 1;-1 -2 -1 -1;5 4 -3 3];
B = [0 0 0 0;0 0 0 0;0 0 0 0;0 0 0 0;0 0 0 0];
X= solveAXB(A, B);
