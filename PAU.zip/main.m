% Matrix erstellen (quadratisch)
A = [0 3 3;-1 3 4; -2 1 5];
B = [2 1 0 ;2 0 1 ;-7 0 0;1 0 0];
X= AxbLoesenMitPLR(A, B);

