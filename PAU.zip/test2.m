#second example
A = [10 -7 0;-3 2 6;5 -1 5];
B = [2 1 0 0;-7 0 1 0;6 0 0 1];
X= solveAXB(A, B);
