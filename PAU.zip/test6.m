#sixth example throws error
A = [2 1 -2 1;1 -2 -1 1;1 1 1 2];
B = [0 0 0;0 0 0;0 0 0;0 0 0];
X= AxbLoesenMitPLR(A, B);

